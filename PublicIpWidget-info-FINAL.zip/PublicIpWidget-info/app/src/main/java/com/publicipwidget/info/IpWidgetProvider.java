package com.publicipwidget.info;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class IpWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_REFRESH = "com.publicipwidget.info.REFRESH";
    private static final long REFRESH_MS = 30_000L;
    private static final ExecutorService EXECUTOR = Executors.newCachedThreadPool();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            showText(context, id, "🌐 Loading...");
            fetchAndUpdate(context, id);
        }
        scheduleNext(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if (ACTION_REFRESH.equals(intent.getAction())) {
            int[] ids = intent.getIntArrayExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS);
            if (ids != null && ids.length > 0) {
                for (int id : ids) {
                    fetchAndUpdate(context, id);
                }
            } else {
                AppWidgetManager manager = AppWidgetManager.getInstance(context);
                int[] allIds = manager.getAppWidgetIds(
                        new android.content.ComponentName(context, IpWidgetProvider.class));
                for (int id : allIds) {
                    fetchAndUpdate(context, id);
                }
            }
            scheduleNext(context);
        }
    }

    @Override
    public void onEnabled(Context context) {
        scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        cancelNext(context);
    }

    private static void fetchAndUpdate(Context context, int appWidgetId) {
        Context appContext = context.getApplicationContext();

        EXECUTOR.execute(() -> {
            String result = getIpInfo();
            android.os.Handler main = new android.os.Handler(context.getMainLooper());
            main.post(() -> showText(appContext, appWidgetId, result));
        });
    }

    private static String getIpInfo() {
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://ipinfo.io/json");
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "PublicIpWidget/1.0");

            int code = connection.getResponseCode();
            InputStream stream = (code >= 200 && code < 300)
                    ? connection.getInputStream()
                    : connection.getErrorStream();

            if (stream == null) return "🌐 Update failed";

            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
            reader.close();

            if (code < 200 || code >= 300) return "🌐 Update failed";

            JSONObject json = new JSONObject(body.toString());
            String ip = json.optString("ip", "");
            String country = json.optString("country", "");

            if (ip.isEmpty()) return "🌐 Update failed";

            String flag = countryToFlag(country);
            return flag + " " + ip;
        } catch (Exception e) {
            return "🌐 Update failed";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String countryToFlag(String countryCode) {
        if (countryCode == null || countryCode.length() != 2) return "🌐";

        countryCode = countryCode.toUpperCase(Locale.US);
        char first = countryCode.charAt(0);
        char second = countryCode.charAt(1);

        if (first < 'A' || first > 'Z' || second < 'A' || second > 'Z') {
            return "🌐";
        }

        return new String(Character.toChars(0x1F1E6 + first - 'A'))
                + new String(Character.toChars(0x1F1E6 + second - 'A'));
    }

    private static void showText(Context context, int appWidgetId, String text) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.ip_widget);
        views.setTextViewText(R.id.ip_text, text);

        Intent refreshIntent = new Intent(context, IpWidgetProvider.class);
        refreshIntent.setAction(ACTION_REFRESH);
        refreshIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{appWidgetId});

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                appWidgetId,
                refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);
        manager.updateAppWidget(appWidgetId, views);
    }

    private static void scheduleNext(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(context, IpWidgetProvider.class);
        intent.setAction(ACTION_REFRESH);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                9911,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        long triggerAt = SystemClock.elapsedRealtime() + REFRESH_MS;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAt,
                    pendingIntent
            );
        } else {
            alarmManager.set(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAt,
                    pendingIntent
            );
        }
    }

    private static void cancelNext(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(context, IpWidgetProvider.class);
        intent.setAction(ACTION_REFRESH);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                9911,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);
    }
}
