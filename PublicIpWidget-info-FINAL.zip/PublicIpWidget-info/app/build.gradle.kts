plugins {
    id("com.android.application")
}

android {
    namespace = "com.publicipwidget.info"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.publicipwidget.info"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
